rm r8s
make
./r8s -f SAMPLE/SAMPLE_SIMPLE

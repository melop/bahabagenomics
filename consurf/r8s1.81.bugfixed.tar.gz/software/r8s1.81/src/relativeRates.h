int doRelativeRates(StrListPtr aTaxaList, NODETYPE * root);

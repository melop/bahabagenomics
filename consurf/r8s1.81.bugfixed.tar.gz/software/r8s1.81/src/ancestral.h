void printAncestral(NODETYPE *node);
void ancestralOptimize(TREE t,int *numIter, double ftol,double linMinDelta,int *success );
double objAncestral(double p[]);

